# Fichier qui exécute sur la plate-forme :

# Les dépendences
pkgs <- c('httr','stringr')

# Installe les dépendences

for(pkg in pkgs){
  if(!require(pkg, character.only = TRUE)){
    system("sudo apt-get install -y libcurl4-openssl-dev", intern=T)
    install.packages(pkg, repos = "https://cloud.r-project.org/")
    library(pkg, character.only = TRUE)
  }
}

# Installe le package
install.packages('youtube_0.1.0.tar.gz', repos = NULL, type = "source")

# Charge la librarie
library(youtube)

# Exécute le main
main(commandArgs(trailingOnly = TRUE))
